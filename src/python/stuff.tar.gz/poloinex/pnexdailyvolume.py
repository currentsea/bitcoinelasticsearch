#{"BTC_1CR":{"BTC":"0.03607564","1CR":"229.47055738"},"BTC_ABY":{"BTC":"0.85532990","ABY":"2903905.80984596"},"BTC_ADN":{"BTC":"0.04039049","ADN":"22666.60830168"},"BTC_ARCH":{"BTC":"0.29308500","ARCH":"56180.78047978"},"BTC_BBR":{"BTC":"2.45170742","BBR":"54295.06451349"},"BTC_BCN":{"BTC":"2.65762073","BCN":"38012419.06120572"},"BTC_BELA":{"BTC":"0.02455835","BELA":"14022.47442465"},"BTC_BITS":{"BTC":"0.01121209","BITS":"1170.25715032"},"BTC_BLK":{"BTC":"5.96404802","BLK":"75979.82702545"},"BTC_BLOCK":{"BTC":"0.55156812","BLOCK":"4898.51300943"},"BTC_BTCD":{"BTC":"2.89944355","BTCD":"1654.09866578"},"BTC_BTM":{"BTC":"3.05721751","BTM":"20849.37767530"},"BTC_BTS":{"BTC":"538.53631698","BTS":"51213035.06140385"},"BTC_BURST":{"BTC":"1.21114290","BURST":"3756937.64350079"},"BTC_C2":{"BTC":"0.00067057","C2":"957.95304452"},"BTC_CGA":{"BTC":"0.01594801","CGA":"444.88812544"},"BTC_CLAM":{"BTC":"66.94873444","CLAM":"40435.60200088"},"BTC_CNMT":{"BTC":"0.08379225","CNMT":"1880.94600000"},"BTC_CURE":{"BTC":"0.02916946","CURE":"1001.89906646"},"BTC_DASH":{"BTC":"1353.85583444","DASH":"108148.98787222"},"BTC_DGB":{"BTC":"126.84004539","DGB":"235406142.27444876"},"BTC_DIEM":{"BTC":"4.57377027","DIEM":"287850157.58146361"},"BTC_DOGE":{"BTC":"132.89631440","DOGE":"241560626.95435608"},"BTC_EMC2":{"BTC":"1.52718795","EMC2":"2329785.14073403"},"BTC_EXE":{"BTC":"0.00000000","EXE":"0.00000000"},"BTC_FIBRE":{"BTC":"0.25934462","FIBRE":"1607.89705107"},"BTC_FLDC":{"BTC":"0.17625404","FLDC":"637097.02879553"},"BTC_FLO":{"BTC":"0.30315578","FLO":"111850.25920164"},"BTC_FLT":{"BTC":"0.06904015","FLT":"137616.11036401"},"BTC_GAP":{"BTC":"0.07422746","GAP":"30524.61028701"},"BTC_GEMZ":{"BTC":"5.34687339","GEMZ":"274459.61902299"},"BTC_GEO":{"BTC":"0.14145908","GEO":"2016.78885260"},"BTC_GMC":{"BTC":"6.89867937","GMC":"190231.20220409"},"BTC_GRC":{"BTC":"4.70878417","GRC":"328439.62913252"},"BTC_GRS":{"BTC":"2.36589924","GRS":"943684.23242164"},"BTC_HUC":{"BTC":"1.39229356","HUC":"47715.00659878"},"BTC_HYP":{"BTC":"0.72930887","HYP":"1224079.07936910"},"BTC_HZ":{"BTC":"1.16186659","HZ":"6213566.70512584"},"BTC_LQD":{"BTC":"0.93558413","LQD":"946.35101636"},"BTC_LTBC":{"BTC":"0.56866961","LTBC":"1820930.87456940"},"BTC_LTC":{"BTC":"296.11154174","LTC":"37733.43414443"},"BTC_MAID":{"BTC":"4188.46116727","MAID":"16265015.59267671"},"BTC_MCN":{"BTC":"0.02765821","MCN":"45878.97772717"},"BTC_MIL":{"BTC":"0.00000000","MIL":"0.00000000"},"BTC_MINT":{"BTC":"0.41715049","MINT":"4110828.46787216"},"BTC_MMC":{"BTC":"0.00000000","MMC":"0.00000000"},"BTC_MMNXT":{"BTC":"0.00000000","MMNXT":"0.00000000"},"BTC_MRS":{"BTC":"0.35636804","MRS":"130506.86990262"},"BTC_OMNI":{"BTC":"1.06654677","OMNI":"214.20892201"},"BTC_MYR":{"BTC":"0.62784973","MYR":"4141778.11956913"},"BTC_NAUT":{"BTC":"0.44508379","NAUT":"8851.74044684"},"BTC_NAV":{"BTC":"0.04766513","NAV":"8625.02072260"},"BTC_NBT":{"BTC":"110.79760162","NBT":"44028.62981043"},"BTC_NEOS":{"BTC":"0.02335937","NEOS":"7584.89168044"},"BTC_NMC":{"BTC":"15.86015262","NMC":"15419.32436408"},"BTC_NOBL":{"BTC":"0.01695603","NOBL":"214600.55966721"},"BTC_NOTE":{"BTC":"0.66177190","NOTE":"40676.77118204"},"BTC_NOXT":{"BTC":"0.00000000","NOXT":"0.00000000"},"BTC_NSR":{"BTC":"3.47204350","NSR":"566895.76202340"},"BTC_NXT":{"BTC":"83.92304607","NXT":"4800339.52670337"},"BTC_PIGGY":{"BTC":"0.00520049","PIGGY":"39815.21065127"},"BTC_PINK":{"BTC":"0.12258158","PINK":"290510.64435396"},"BTC_POT":{"BTC":"0.56118068","POT":"268660.88298170"},"BTC_PPC":{"BTC":"10.58816953","PPC":"9563.59515821"},"BTC_PTS":{"BTC":"0.11862574","PTS":"589181.42876755"},"BTC_QBK":{"BTC":"0.02831458","QBK":"152.46747042"},"BTC_QORA":{"BTC":"4.41545756","QORA":"72886986.22482321"},"BTC_QTL":{"BTC":"0.56313219","QTL":"50492.22192912"},"BTC_RBY":{"BTC":"7.68157494","RBY":"24151.33676421"},"BTC_RDD":{"BTC":"13.63921749","RDD":"202903677.92714478"},"BTC_RIC":{"BTC":"0.22874916","RIC":"6261.44311133"},"BTC_SDC":{"BTC":"2.08085936","SDC":"11374.13244464"},"BTC_SILK":{"BTC":"0.50890313","SILK":"119740.75102521"},"BTC_SJCX":{"BTC":"212.93105595","SJCX":"1385139.10141334"},"BTC_STR":{"BTC":"42.02484627","STR":"9336792.83419414"},"BTC_SWARM":{"BTC":"0.75441902","SWARM":"63188.56485215"},"BTC_SYNC":{"BTC":"0.00396473","SYNC":"0.06955666"},"BTC_SYS":{"BTC":"94.79082841","SYS":"14516412.70011744"},"BTC_UNITY":{"BTC":"1.16675088","UNITY":"519.35332164"},"BTC_VIA":{"BTC":"1.55343382","VIA":"110822.70310023"},"BTC_VNL":{"BTC":"38.07260777","VNL":"197812.25777916"},"BTC_VRC":{"BTC":"4.15690971","VRC":"41810.57126828"},"BTC_VTC":{"BTC":"9.32874491","VTC":"87331.44820176"},"BTC_WDC":{"BTC":"1.21350026","WDC":"65059.34882501"},"BTC_XBC":{"BTC":"0.40452960","XBC":"963.52003870"},"BTC_XC":{"BTC":"0.01031475","XC":"161.77600000"},"BTC_XCH":{"BTC":"0.20259407","XCH":"183618.46891765"},"BTC_XCN":{"BTC":"1.02936074","XCN":"453682.89081384"},"BTC_XCP":{"BTC":"10.22381820","XCP":"6608.57260996"},"BTC_XCR":{"BTC":"0.96397337","XCR":"83869.11269657"},"BTC_XDN":{"BTC":"4.31171173","XDN":"28739258.77966054"},"BTC_XDP":{"BTC":"0.05431527","XDP":"713.95898211"},"BTC_XEM":{"BTC":"148.77663426","XEM":"87457873.77243942"},"BTC_XMG":{"BTC":"0.46228747","XMG":"18070.34524243"},"BTC_XMR":{"BTC":"2759.77591786","XMR":"889490.33071738"},"BTC_XPB":{"BTC":"0.09218003","XPB":"12672.01036008"},"BTC_XPM":{"BTC":"0.92857333","XPM":"4593.73877573"},"BTC_XRP":{"BTC":"452.32299214","XRP":"23523146.94939826"},"BTC_XST":{"BTC":"0.05660342","XST":"4711.62505476"},"BTC_XUSD":{"BTC":"0.02922210","XUSD":"12.33000000"},"BTC_YACC":{"BTC":"0.60468447","YACC":"8441038.36976709"},"USDT_BTC":{"USDT":"142797.47796573","BTC":"365.65420968"},"USDT_DASH":{"USDT":"372.08121280","DASH":"77.73841825"},"USDT_LTC":{"USDT":"1670.86967403","LTC":"539.57566248"},"USDT_NXT":{"USDT":"425.48813895","NXT":"61934.30102665"},"USDT_STR":{"USDT":"85.81540071","STR":"48847.45302740"},"USDT_XMR":{"USDT":"4474.62841933","XMR":"3421.82320029"},"USDT_XRP":{"USDT":"406.23913316","XRP":"52782.68143251"},"XMR_BBR":{"XMR":"36.21988968","BBR":"2423.79866780"},"XMR_BCN":{"XMR":"6.19042161","BCN":"281686.75835143"},"XMR_BLK":{"XMR":"11.45313898","BLK":"431.06188985"},"XMR_BTCD":{"XMR":"6.37400394","BTCD":"9.65353382"},"XMR_DASH":{"XMR":"671.49763648","DASH":"172.47871488"},"XMR_DIEM":{"XMR":"335.97532600","DIEM":"95442862.18833920"},"XMR_DSH":{"XMR":"12.94139967","DSH":"6030.50225773"},"XMR_HYP":{"XMR":"4.92115853","HYP":"24822.63442953"},"XMR_IFC":{"XMR":"0.10652637","IFC":"14361.43064445"},"XMR_LTC":{"XMR":"4056.89147004","LTC":"1568.11829015"},"XMR_MAID":{"XMR":"2400.80441386","MAID":"31360.60171961"},"XMR_MNTA":{"XMR":"0.11923545","MNTA":"100.29900000"},"XMR_NXT":{"XMR":"40.65869348","NXT":"7573.24155206"},"XMR_QORA":{"XMR":"43.66569427","QORA":"2106729.34581282"},"XMR_XDN":{"XMR":"697.28872485","XDN":"15720394.95913871"},"BTC_IOC":{"BTC":"1.47710449","IOC":"30322.36891857"},"BTC_INDEX":{"BTC":"0.27699403","INDEX":"0.48609310"},"BTC_ETH":{"BTC":"91077.33673925","ETH":"3212814.94408831"},"USDT_ETH":{"USDT":"152099.78616296","ETH":"13465.92697092"},"BTC_SC":{"BTC":"36.49360184","SC":"192546636.75714350"},"BTC_BCY":{"BTC":"9.07954565","BCY":"74377.82243689"},"BTC_EXP":{"BTC":"645.74847197","EXP":"447424.24877849"},"BTC_FCT":{"BTC":"3672.15289621","FCT":"926049.98947575"},"BTC_BITUSD":{"BTC":"0.01082114","BITUSD":"4.57689147"},"BTC_BITCNY":{"BTC":"0.00385229","BITCNY":"10.00000000"},"BTC_RADS":{"BTC":"308.34257083","RADS":"355111.76854100"},"totalBTC":"106550.51992489","totalUSDT":"302332.38610767","totalXMR":"8325.10773321","totalXUSD":"0.00000000"}

# Author: Joseph Bull 
# Copyright 2016 
# Do Not Redistribute 
# Long Live Bitcoin! 

import argparse, hmac, hashlib, time, json, urllib, urllib2, requests, pytz, elasticsearch, poloinex, uuid, datetime
from time import sleep
ELASTICSEARCH_HOST = "https://search-bitcoins-2sfk7jzreyq3cfjwvia2mj7d4m.us-west-2.es.amazonaws.com/" 

def getArgs(): 
	parser = argparse.ArgumentParser(description='BTC elastic search data collector')
	parser.add_argument('--host', default=ELASTICSEARCH_HOST) 
	parser.add_argument('--forever', action='store_true', default=False)
	parser.add_argument('--max_records', action='store_true', default=3600)
	args = parser.parse_args()
	return args

def getIndeces(elasticHost): 
	pass

def getDtoList(connector): 
	dtoList = []
	tickerData = connector.return24Volume()
	for item in tickerData: 
		dto = {}
		uniqueId = uuid.uuid4()
		dto["uuid"] = str(uniqueId)
		dto["date"] = datetime.datetime.utcnow()
		dto["currency_pair"] = item
		itemDict = tickerData[item]
		# for key in itemDict: 
		# 	dto[key] = itemDict[key]
		# dtoList.append(dto)
		print item
	pass
	#return dtoList

def createIndex(es, name): 
	try: 
		es.indices.get(name)
	except elasticsearch.exceptions.NotFoundError: 
		# print ("Index " + name + " already existed on target host. Continuing...")
		# pass
		print es.indices.create(name)
	except:
		raise

def putMapping(es, indexName, docType): 
	try: 
		pnexTickersMapping = {
			"daily_volume": {
				"properties": {
					"uuid": { "type": "string"},
					"date": {"type": "date"},
					"curency_pair": { "type": "string"},
					"value_pair_left": {"type": "float"}, 
					"value_pair_right": {"type":"float"} 
				} 
			} 
		}  
		es.indices.put_mapping(index=indexName, doc_type=docType, body=pnexTickersMapping)
	except: 
		raise 

def injectData(es, indexName, docType, docBody, conDocs): 	
	putNewDocumentRequest = es.create(index=indexName, doc_type=docType, ignore=[400], id=uuid.uuid4(), body=docBody)
	successful = putNewDocumentRequest["created"]
	if successful == True: 
		print "Added data for " + docType + " (docs consecutively added this run: " + str(conDocs) + ")"
	else: 
		raise

if __name__ == "__main__": 
	args = getArgs()
	indexName = "volume_exchange_data" 
	docType = "poloinex"
	#print args.host
	conDocs = 0
	es = elasticsearch.Elasticsearch(args.host, verify_certs=True) 
	createIndex(es, indexName) 
	putMapping(es, indexName, docType) 
	connector = poloinex.poloniex("", "")
	while 1 == 1: 
		tickerData = getDtoList(connector)
		sleep(0.5)
		for dataPoint in tickerData: 
			conDocs = conDocs + 1
			injectData(es, indexName, docType, dataPoint, conDocs)