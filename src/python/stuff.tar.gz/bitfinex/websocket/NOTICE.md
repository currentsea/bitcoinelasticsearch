This is a fork taken on 1/2/2016 at 11:08PM of the following Repo: https://github.com/OKCoin/websocket/tree/master/python
