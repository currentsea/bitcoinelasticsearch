from okcoin import Okcoin

okcoin = Okcoin()
print (okcoin.run())
