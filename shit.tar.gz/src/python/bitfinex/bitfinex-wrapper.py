from bitfinex import Bitfinex

bfx = Bitfinex()
print (bfx.run())
