# PLEASE DONATE TO KEEP PROJECT ALIVE

### DONATION ADDRESS: 1KK5chYWRrNhoRdgzhR8eKmRRq7Fz5aMKC

```
### Your donations and tips are  appreciated! ### 
```

# bitcoinelasticsearch
# Bitcoin Elasticsearch connector 
Bitcoin elasticsearch data harvesting tool for Bitfinex, Okcoin, and many more to come :)  


# Python 3.5
Requirements: 
* Python
* Pip 
* An elasticsearch server of some kind
* The following: 
```
pip3 install elasticsearch
pip3 install requests
pip3 install argparse

(if you are using the websocket script) 

## YOU NEED TO USE PYTHON3 FOR THE WEBSOCKET SCRIPT ##

pip3 install pytz

GET THE WEBSOCKET DEPENDENCY FROM OKCOIN (** NOT THE WEBSOCKET(S) [plural]) 
https://github.com/OKCoin/websocket/tree/master/python/websocket
``` 

Will add more to readme when im not lazy 

