This directory contains kibana dashboards that can be used to visualize this data. 

In order to restore them to your kibana dashboard, simply go to Settings --> Objects --> Import and select the JSON file that corresponds to the dashboard you wish to import.  

* Single visualization objects (i.e. a single chart or metric) can be found in the `visualizations` directory 

* Screenshots of the different visualizations (as a reference for potential users to see what is possible) can be found in the screenshtos directory

