NOTICE: 

This repository contains code from the OkCoin Websocket connector located at https://github.com/OKCoin/websocket and is licensed under the LGPL.  This is notice that we are utilziing portions of the library to make our connections. 

The referenced LGPL library can be found in /python-scripts/websocket/ 

Please contact Donny Devito (donnydevito) if there are any questions, comments, or concerns. 